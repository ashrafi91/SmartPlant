import 'package:flutter/material.dart';
import 'package:smartplant/BottomBarScreens/HomePage.dart';
import 'package:smartplant/BottomBarScreens/MyPlants/PlantMainPage.dart';
import 'package:smartplant/BottomBarScreens/MySyte/MySiteMainPage.dart';
import 'package:smartplant/BottomBarScreens/Search.dart';
import 'package:smartplant/BottomBarScreens/User.dart';

class MainBoard extends StatefulWidget {
  //const MainBoard({Key? key}) : super(key: key);

  @override
  _MainBoardState createState() => _MainBoardState();
}

class _MainBoardState extends State<MainBoard> {
  int _currentIndex = 0;
  final List _children = [
    HomePage(),
    MySiteMainPage(),
    PlantMainPage(),
    Search(),
    User()
  ];
  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {
   return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex:_currentIndex,
          onTap: onTabTapped,
          selectedItemColor: Color(0xff007360),
          unselectedItemColor: Color(0xffC8DBCF),
          type: BottomNavigationBarType.fixed,
         // showSelectedLabels: true,

          items: [
      BottomNavigationBarItem(
      icon: Icon(Icons.home,size: 24,),
      label: 'Home',
      ),
      BottomNavigationBarItem(
      icon: Image.asset("assets/icons/watercann.png",width: 24,height: 24,),
      label: 'My Site',
    ),
    BottomNavigationBarItem(
    icon: Image.asset("assets/icons/myplant.png",width: 24,height: 24,),
    label: 'My Plants',
    ),
    BottomNavigationBarItem(
     icon: Icon(Icons.search,size: 24,),
     label: 'Search',
     ),
    BottomNavigationBarItem(
    icon: Icon(Icons.person,size: 24,),
    label: 'User',
    ),
    ]
    ),
      body: _children[_currentIndex],
    );
  }
}
