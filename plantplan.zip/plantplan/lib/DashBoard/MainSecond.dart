import 'package:date_picker_timeline/date_picker_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:intl/intl.dart';

class MainSecond extends StatefulWidget {
  //const DoorSelection({Key? key}) : super(key: key);

  @override
  _DoorSelectionState createState() => _DoorSelectionState();
}
class _DoorSelectionState extends State<MainSecond> {
  static final DateTime now = DateTime.now();
  static final DateFormat formatter = DateFormat('yMMMd');
  static final DateFormat formatterday = DateFormat('EEEE');
  static final DateFormat year = DateFormat('yyyy');
  static final DateFormat monthfrm = DateFormat('MMM');
  final String date = formatter.format(now);
  final String dtname = formatterday.format(now);
   String monthselect;

  @override
  Widget build(BuildContext context) {
    DatePickerController _controller = DatePickerController();

    DateTime _selectedValue = DateTime.now();
    DateTime selectedDate = DateTime.now();
    String yearselect;
    Future<void> _selectDate(BuildContext context) async {
      final DateTime picked = await showDatePicker(
          context: context,
          initialDate: selectedDate,
          firstDate: DateTime(2021),
          lastDate: DateTime(2101));
      if (picked != null && picked != selectedDate)
        setState(() {
          selectedDate = picked;
        });
    }

    return Scaffold(
      resizeToAvoidBottomInset: true,

      backgroundColor: Color(0xff007360),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: SingleChildScrollView(
          child: Stack(
            overflow: Overflow.visible,
            alignment: AlignmentDirectional.topCenter,
            fit: StackFit.loose,
            children: [
              Container(
                height: MediaQuery.of(context).size.height*0.25,
                child: Column(
                  children: [
                    SizedBox(height: 30,),
                    Padding(
                      padding: const EdgeInsets.only(left:10.0,right: 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text('Good Morning, John',style: TextStyle(color: Color(0xffffffff),fontWeight:
                                FontWeight.w700,fontSize: 18,fontStyle: FontStyle.normal),),
                              ),
                              SizedBox(height: 10,),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text('$dtname ,$date',style: TextStyle(color: Color(0xffF0F0F0),fontWeight:
                                FontWeight.w400,fontSize: 14,fontStyle: FontStyle.normal),),
                              ),
                            ],
                          ),
                          Icon(Icons.notifications,color:Color(0xffffffff),),

                        ],
                      ),
                    ),

                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: MediaQuery.of(context).size.height*0.2),
                //  alignment: Alignment.bottomCenter,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height*0.78,
                  decoration: BoxDecoration(
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))
                  ),
                  child: Column(
                    children: [
                      SizedBox(height: 60,),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Align(
                            alignment: Alignment.center,
                            child: Container(
                              width: 111,
                              height: 29,
                              decoration:  BoxDecoration(
                                  color: Color(0xffFCF1DE),
                                  borderRadius: BorderRadius.all( Radius.circular(10))
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceAround,
                                children: [
                                  Image.asset("assets/icons/award.png"),
                                  Text("Beginner",style: TextStyle(fontSize: 12,fontWeight: FontWeight.w400,color: Color(0xffF0B44F)),)
                                ],
                              ),

                            )
                        ),
                      ),
                  SizedBox(height: 10,),
                      Divider(),
                      Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Select Date",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: Color(0xff202D50)),)
                          ,Row(

                            children: [
                              Text("${monthselect==null?monthfrm.format(selectedDate):monthselect} ${yearselect==null?year.format(selectedDate):yearselect}",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: Color(0xff202D50)),)
,
                              IconButton(
                                  icon:Icon(Icons.date_range),
                                    onPressed:(){
                                    setState(() {
                                      yearselect=year.format(selectedDate);
                                    });
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(

                                            title: Text("Select Year"),
                                            content: Container( // Need to use container to add size constraint.
                                              width: 300,
                                              height: 300,
                                              child: YearPicker(
                                                firstDate: DateTime(DateTime.now().year - 100, 1),
                                                lastDate: DateTime(DateTime.now().year + 100, 1),
                                                initialDate: DateTime.now(),
                                                // save the selected date to _selectedDate DateTime variable.
                                                // It's used to set the previous selected date when
                                                // re-showing the dialog.
                                                selectedDate: selectedDate,
                                                onChanged: (DateTime dateTime) {

                                                  // close the dialog when year is selected.
                                                  Navigator.pop(context);

                                                  // Do something with the dateTime selected.
                                                  // Remember that you need to use dateTime.year to get the year
                                                },
                                              ),
                                            ),
                                          );
                                        },
                                      );
                                    },
                                      //_selectDate(context),

                                    ),
                            ],
                          )

                          ],

                        ),
                      ),
                      Container(
                        child: DatePicker(
                          DateTime.now(),
                          width: 60,
                          height: 80,
                          controller: _controller,
                          initialSelectedDate: DateTime.now(),
                          selectionColor: Colors.green,
                          selectedTextColor: Colors.white,
                          inactiveDates: [
                            DateTime.now().add(Duration(days: 3)),
                            DateTime.now().add(Duration(days: 4)),
                            DateTime.now().add(Duration(days: 7))
                          ],
                          onDateChange: (date) {
                            // New date selected
                            setState(() {
                              _selectedValue = date;
                              monthselect=monthfrm.format(date);
                            });
                          },
                        ),
                      ),
                      SizedBox(height: 10,),
                      Divider(),
                      Column(
                        children: [
                          Text("Todays Task",style: TextStyle(
                              fontSize: 16,fontWeight: FontWeight.w600,color: Color(0xff202D50)),)
                              ,SizedBox(height: 10,)
                                ,Row(
                                  children: [
                                    SizedBox(width: 10,),
                                    Text("Order by :",style: TextStyle(
                                        fontSize: 9,fontWeight: FontWeight.w400,color: Color(0xff3D4864)),)
                                   ,
                                    SizedBox(width: 10,),
                                    Container(
                                      width: 43,
                                      height: 24,
                                      decoration:  BoxDecoration(
                                          color: Color(0xff007360),
                                          borderRadius: BorderRadius.all( Radius.circular(10),
                                          ),
                                      ),
                                      child:  Center(
                                        child: Text("Tasks :",style: TextStyle(
                                            fontSize: 9,fontWeight: FontWeight.w400,color: Color(0xffffffff)),),
                                      )

                                    ),
                                    SizedBox(width: 10,),
                                    Container(
                                        width: 43,
                                        height: 24,
                                        decoration:  BoxDecoration(
                                          color: Color(0xffF1F6F3),
                                          borderRadius: BorderRadius.all( Radius.circular(10),
                                          ),
                                        ),
                                        child:  Center(
                                          child: Text("Plants",style: TextStyle(
                                              fontSize: 9,fontWeight: FontWeight.w400,color: Color(0xff007360)),),
                                        )

                                    ),
                                    SizedBox(width: 10,),
                                    Container(
                                        width: 43,
                                        height: 24,
                                        decoration:  BoxDecoration(
                                          color: Color(0xffF1F6F3),
                                          borderRadius: BorderRadius.all( Radius.circular(10),
                                          ),
                                        ),
                                        child:  Center(
                                          child: Text("Sites",style: TextStyle(
                                              fontSize: 9,fontWeight: FontWeight.w400,color: Color(0xff007360)),),
                                        ),

                                    ),
                                  ],
                                ),

                        ],
                      ),
                      SizedBox(width: 10,),
                        Padding(
                          padding: EdgeInsets.only(left: 20,right: 20,top: 10),
                          child: Container(

                          child:      Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [

                                    Container(
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text("Water",style: TextStyle(
                                                fontSize: 14,fontWeight: FontWeight.w600,color: Color(0xff202D50)),),

                                          SizedBox(height: 10,),
                                            Text("Tap to each item for care instruction",style: TextStyle(
                                                fontSize: 9,fontWeight: FontWeight.w400,color: Color(0xff3D4864)),),


                                        ],
                                      ),
                                    ),
                                   ImageIcon(AssetImage("assets/icons/watercann.png",),size: 24,color: Color(
                                       0xffaf9e9e),),

                                  ],
                                ),

                          ),

                        ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Divider(),
                      )

                    ],


                  ),
                ),
              ),

              Positioned(
                  top:MediaQuery.of(context).size.height*0.15,
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.all(Radius.circular(10))
                    ),

                    height: 90,
                    width: 90,
                    child: Image.asset("assets/icons/QR.png"),
                  )
              )

              // CircleAvatar(
              //   radius: 50,
              //   backgroundImage:
              //   AssetImage('assets/icons/QR.png'),
              // )),
            ],
          ),
        ),
      ),

    );
  }
}
