import 'package:flutter/material.dart';

class PlantMainPage extends StatefulWidget {
 // const PlantMainPage({Key? key}) : super(key: key);

  @override
  _PlantMainPageState createState() => _PlantMainPageState();
}

class _PlantMainPageState extends State<PlantMainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(color: Colors.purpleAccent,),
    );
  }
}
