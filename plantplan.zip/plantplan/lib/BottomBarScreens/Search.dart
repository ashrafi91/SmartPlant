import 'package:flutter/material.dart';

class Search extends StatefulWidget {
  //const State({Key? key}) : super(key: key);

  @override
  _StateState createState() => _StateState();
}

class _StateState extends State<Search> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.red,
      ),
    );
  }
}
