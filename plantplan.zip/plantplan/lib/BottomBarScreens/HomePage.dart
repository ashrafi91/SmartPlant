import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:intl/intl.dart';
import 'package:smartplant/DashBoard/MainSecond.dart';

class HomePage extends StatefulWidget {
  //const DoorSelection({Key? key}) : super(key: key);

  @override
  _DoorSelectionState createState() => _DoorSelectionState();
}
class _DoorSelectionState extends State<HomePage> {
    static final DateTime now = DateTime.now();
    static final DateFormat formatter = DateFormat('yMMMd');
    static final DateFormat formatterday = DateFormat('EEEE');
    final String date = formatter.format(now);
    final String dtname = formatterday.format(now);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,

      backgroundColor: Color(0xff007360),
      body: Container(
        height: double.infinity,
        width: double.infinity,
        child: SingleChildScrollView(
          child: Stack(
            overflow: Overflow.visible,
            alignment: AlignmentDirectional.topCenter,
            fit: StackFit.loose,
              children: [
                Container(
                  height: MediaQuery.of(context).size.height*0.25,
                            child: Column(
                              children: [
                                SizedBox(height: 30,),
                                Padding(
                                  padding: const EdgeInsets.only(left:10.0,right: 10),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        children: [
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text('Good Morning, John',style: TextStyle(color: Color(0xffffffff),fontWeight:
                                            FontWeight.w700,fontSize: 18,fontStyle: FontStyle.normal),),
                                          ),
                                          SizedBox(height: 10,),
                                          Align(
                                            alignment: Alignment.topLeft,
                                            child: Text('$dtname ,$date',style: TextStyle(color: Color(0xffF0F0F0),fontWeight:
                                            FontWeight.w400,fontSize: 14,fontStyle: FontStyle.normal),),
                                          ),
                                        ],
                                      ),
                                      Icon(Icons.notifications,color:Color(0xffffffff),),

                                    ],
                                  ),
                                ),

                              ],
                            ),
                          ),
                     Container(
                       margin: EdgeInsets.only(top: MediaQuery.of(context).size.height*0.2),
                     //  alignment: Alignment.bottomCenter,
                       child: Container(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height*0.78,
                        decoration: BoxDecoration(
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))
                        ),
                        child: Column(
                          children: [
                            SizedBox(height: 60,),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Align(
                                alignment: Alignment.center,
                                child: Container(
                                  width: 111,
                                  height: 29,
                                decoration:  BoxDecoration(
                                      color: Color(0xffFCF1DE),
                                      borderRadius: BorderRadius.all( Radius.circular(10))
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    children: [
                                      Image.asset("assets/icons/award.png"),
                                      Text("Beginner",style: TextStyle(fontSize: 12,fontWeight: FontWeight.w400,color: Color(0xffF0B44F)),)
                                    ],
                                  ),
                                )
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Align(
                                alignment: Alignment.center,
                                child:  RichText(text: TextSpan(
                                    text: "Your fresh and green\n",
                                    style: TextStyle(
                                        fontSize: 24,fontWeight: FontWeight.w700,fontStyle: FontStyle.normal,color: Colors.black),
                                    children: [
                                      TextSpan(text: "comfortable ",style:TextStyle(
                                          fontSize: 24,fontWeight: FontWeight.w700,
                                           fontStyle: FontStyle.normal,color: Colors.black)   ),
                                      TextSpan(text: "place",style:TextStyle(
                                          fontSize: 24,fontWeight: FontWeight.w700,
                                          fontStyle: FontStyle.normal,color: Colors.green[700])   ),
                                    ]
                                )     ),


                                //Text('Your fresh and green\n comfortable place',style: TextStyle(color: Color(0xff202D50),fontWeight:
                              //  FontWeight.w700,fontSize: 24,fontStyle: FontStyle.normal),),
                              ),
                            ),

                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Align(
                             //   alignment: Alignment.topLeft,
                                child:  TextField(
                                  keyboardType: TextInputType.text,
                                //  controller: phoneEditingController,
                                  style: TextStyle(color: Color(0xff3D4864)),
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      fillColor: Color(0x29D5CACA),
                                      prefixIcon: Padding(padding: EdgeInsets.all(15),
                                          child: Icon(Icons.search,size: 18,color: Color(0xff75A488),)),
                                      filled: true,
                                      labelText: 'Search now',
                                      labelStyle: TextStyle(color: Color(0xff75A488),fontSize: 14,fontWeight: FontWeight.w400)
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left:10.0),
                              child: Align(
                                  alignment: Alignment.topLeft,
                                  child: Text("Todays Task",style:TextStyle(
                                      color: Color(0xff202D50),fontSize: 16,fontWeight: FontWeight.w600)
                                  )),
                            ),
                            Expanded(
                                child: Padding(
                                  padding: EdgeInsets.all(10),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.all(Radius.circular(10)),
                                      border: Border(
                                          top: BorderSide(color: Color(0xffF0F0F0),width: 1),
                                        bottom: BorderSide(color: Color(0xffF0F0F0),width: 1),
                                        left: BorderSide(color: Color(0xffF0F0F0),width: 1),
                                        right: BorderSide(color: Color(0xffF0F0F0),width: 1),
                                      )
                                    ),
                                      child:SingleChildScrollView(
                                        child: Column(
                                          children: [
                                            Image.asset("assets/icons/todaytask.png",),
                                            Padding(
                                              padding: const EdgeInsets.all(20.0),
                                              child: GestureDetector(
                                                onTap: (){

                                                  Navigator.push(
                                                      context,
                                                      MaterialPageRoute(builder: (context) => MainSecond())
                                                  );

                                                },
                                                child: Padding(
                                                  padding: const EdgeInsets.only(top: 12.0),
                                                  child: Container(
                                                    height: MediaQuery.of(context).size.height*0.08,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xff007360),

                                                      borderRadius: BorderRadius.circular(20),
                                                    ),
                                                    child: Center(
                                                      child: Text("Add Your First Room",style: TextStyle(
                                                          color: Colors.white,fontSize: 14,fontWeight: FontWeight.w600),),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(height: 20,)
                                          ],
                                        ),
                                      ),
                                  ),
                                )
                            ),
                            // Expanded(
                            //   child: Container(),
                            // ),

                          ],

                        ),
                  ),
                     ),

                Positioned(
                    top:MediaQuery.of(context).size.height*0.15,
                    child: Container(
                      decoration: BoxDecoration(
                          color: Colors.blue,
                        borderRadius: BorderRadius.all(Radius.circular(10))
                      ),

                      height: 90,
                      width: 90,
                      child: Image.asset("assets/icons/QR.png"),
                    )
                    )

                    // CircleAvatar(
                    //   radius: 50,
                    //   backgroundImage:
                    //   AssetImage('assets/icons/QR.png'),
                    // )),
              ],
            ),
        ),
      ),

    );
  }
}
