import 'package:flutter/material.dart';

class MySiteMainPage extends StatefulWidget {
 // const MySiteMainPage({Key? key}) : super(key: key);

  @override
  _MySiteMainPageState createState() => _MySiteMainPageState();
}

class _MySiteMainPageState extends State<MySiteMainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.green,
      ),
    );
  }
}
