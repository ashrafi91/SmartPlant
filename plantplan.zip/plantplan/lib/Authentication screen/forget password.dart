import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ForgetPassword extends StatelessWidget {
 // const ForgetPassword({Key? key}) : super(key: key);

TextEditingController email=new TextEditingController();
bool passvalidate=false;
FirebaseAuth _auth=FirebaseAuth.instance;
_passwordreset(BuildContext context){
  _auth.sendPasswordResetEmail(email: email.text);
  Navigator.pop(context);
}
  @override
  Widget build(BuildContext context) {
    var h=MediaQuery.of(context).size.height;
    return Scaffold(

      body: Container(

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Container(
                height: h*0.08,
                child: TextField(
                  controller: email,
                  // onChanged: (val){
                  //   setState(() {
                  //     isEnabled=true;
                  //   });
                  // },
                  style: TextStyle(color: Color(0xff202D50)),
                  obscureText: false,
                  decoration: InputDecoration(
                      fillColor: Color(0x29FFFFFF),
                      filled: true,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14.0),
                          borderSide: new BorderSide(color: Color(0xff3D4864))
                      ),
                      enabledBorder:  OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide:  BorderSide(color:Color(0xff3D4864), width: 0.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide:  BorderSide(color: Color(0xff3D4864), width: 0.0),
                      ),
                      labelText: 'email',
                      labelStyle: TextStyle(color: Color(0xff3D4864)),
                     errorText: passvalidate?"invild Password":null
                  ),
                ),
              ),
            ),


            SizedBox(height: 30,),
            GestureDetector(
              onTap: (){

                //login();


                    email.text.isEmpty ? passvalidate = true : passvalidate = false;
                  if(email.text.isNotEmpty) {
                    _passwordreset(context);
                  }
                  // Navigator.push(
                  //     context,
                  //     MaterialPageRoute(builder: (context) => firstplant())
                  // );
                },

              child: Padding(
                padding: const EdgeInsets.only(top: 12.0),
                child: Container(

                  height: h*0.08,
                  decoration: BoxDecoration(
                  //  color:isEnabled? Colors.green: Color(0xff007360),
                    color: Color(0xff007360),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Center(
                    child: Text("Reset Password",style: TextStyle(color: Colors.white,fontSize: 14,fontWeight: FontWeight.w600),),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
