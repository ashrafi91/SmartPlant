import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:smartplant/Indoor&outdoor/doorSelection.dart';

class OtpScreen extends StatefulWidget {
  const OtpScreen({Key key, this.phoneNumber,this.username}) : super(key: key);

 // const OtpScreen({Key? key}) : super(key: key);
  final String phoneNumber;
  final String username;


  @override
  _OtpScreenState createState() => _OtpScreenState();


}

class _OtpScreenState extends State<OtpScreen> {

  var onTapRecognizer;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // Future registerUser()async {
  //   await FirebaseAuth.instance.verifyPhoneNumber(
  //     phoneNumber: widget.phoneNumber,
  //     verificationCompleted: (PhoneAuthCredential credential) async {
  //       // ANDROID ONLY!
  //       print("register through number");
  //       // Sign the user in (or link) with the auto-generated credential
  //       await _auth.signInWithCredential(credential);
  //     },
  //
  //     verificationFailed: (FirebaseAuthException e) {
  //       if (e.code == 'invalid-phone-number') {
  //         print('The provided phone number is not valid.');
  //       }
  //     },
  //     codeSent: (String verificationId, int resendToken) async {
  //       // Update the UI - wait for the user to enter the SMS code
  //       String smsCode = onTapRecognizer;
  //
  //       // Create a PhoneAuthCredential with the code
  //       PhoneAuthCredential credential = PhoneAuthProvider.credential(
  //           verificationId: verificationId, smsCode: smsCode);
  //
  //       // Sign the user in (or link) with the credential
  //       await _auth.signInWithCredential(credential);
  //     },
  //     codeAutoRetrievalTimeout: (String verificationId) {
  //       print("resend please");
  //     },
  //   );
  // }
  // Future registerUser(String mobile, BuildContext context) async{
  //
  //   FirebaseAuth _auth = FirebaseAuth.instance;
  //
  //   _auth.verifyPhoneNumber(
  //       phoneNumber: mobile,
  //       timeout: Duration(seconds: 60),
  //       verificationCompleted: (AuthCredential authcraditonal) {
  //         _auth.signInWithCredential(authcraditonal).then((value) {
  //           Navigator.pushReplacement(
  //               context,
  //               MaterialPageRoute(builder: (context) =>
  //                   DoorSelection())
  //           );
  //         });
  //       },
  //       verificationFailed: null,
  //       codeSent:  (String verificationId, [int forceResendingToken]){
  //         //show dialog to take input from the user
  //       },
  //       codeAutoRetrievalTimeout: null
  //   );
  // }
  TextEditingController textEditingController = TextEditingController();
  // ..text = "123456";
String verificationCode;
final GlobalKey<ScaffoldState> scafoldkey=GlobalKey<ScaffoldState>();
  StreamController<ErrorAnimationType> errorController;
  phoneSignIn() async {
    await _auth.verifyPhoneNumber(
        phoneNumber: "+92 ${widget.phoneNumber}",
        verificationCompleted:(PhoneAuthCredential cradition)async{
        _auth.signInWithCredential(cradition).then((value) async{
          if(value.user!=null) {
            print("user log in");
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>DoorSelection()));
          }
        });
        },
        verificationFailed: (FirebaseAuthException e){
          print(e.message);
        },
        codeSent: (String verification,int resendCose){
          setState(() {
            verificationCode=verification;
          });

        },
        codeAutoRetrievalTimeout:(String verificationid){
          setState(() {
            verificationCode=verificationid;
          });

        },
        timeout: Duration(seconds: 60)
    );
  }
  bool hasError = false;
  String currentText = "";
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    onTapRecognizer = TapGestureRecognizer()
      ..onTap = () {
        Navigator.pop(context);
      };
    phoneSignIn();
    errorController = StreamController<ErrorAnimationType>();
    super.initState();
  }

  @override
  void dispose() {
    errorController.close();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFFFFFF),
      appBar: AppBar(
        backgroundColor: Color(0xffFFFFFF),
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        elevation: 0.0,
        title: Text("OTP",style: TextStyle(
            color: Colors.black,fontSize: 18,fontWeight: FontWeight.w400,),),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
              Container(
                height: MediaQuery.of(context).size.height*0.3,
                width: MediaQuery.of(context).size.width,
              child: Image.asset("assets/icons/imageOTP.png"),),
             Container(
                 // height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,

                child: Column(children: [
                  Text("Verification code",style: TextStyle(
                    color: Colors.black,fontSize: 24,fontWeight: FontWeight.w700,),),
                  SizedBox(height: 10,),
                  Text("We have sent the codeverification to",style: TextStyle(
                    color: Color(0xff3D4864),fontSize: 14,fontWeight: FontWeight.w700,),),
                  SizedBox(height: 10,),
                  RichText(text: TextSpan(
                      // text: "We have sent the codeverification to\n",
                      // style: TextStyle(
                      //     fontSize: 14,fontWeight: FontWeight.w700,
                      //     fontStyle: FontStyle.normal,color: Color(0x66766d6d)),
                      children: [

                        TextSpan(text: "your number",style:TextStyle(
                            fontSize: 14,fontWeight: FontWeight.w700,
                            fontStyle: FontStyle.normal,color: Color(0xff3D4864))   ),
                        TextSpan(text: "${widget.phoneNumber}",style:TextStyle(
                            fontSize: 14,fontWeight: FontWeight.w700,
                            fontStyle: FontStyle.normal,color: Color(0xff3D4864))   ),
                        TextSpan(text: " Change",style:TextStyle(
                            fontSize: 14,fontWeight: FontWeight.w700,
                            fontStyle: FontStyle.normal,color: Color(0xff3D4864))   ),
                      ]
                  )     ),
                  SizedBox(height: 20,),
                  Form(
                    key: formKey,
                    child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 30),
                        child: PinCodeTextField(
                          appContext: context,
                          pastedTextStyle: TextStyle(
                            color: Colors.green.shade600,
                            fontWeight: FontWeight.bold,
                          ),
                          length: 6,
                          obscureText: false,
                          obscuringCharacter: '*',
                          animationType: AnimationType.fade,
                          validator: (v) {
                            if (v.length < 3) {
                              return "I'm from validator";
                            } else {
                              return null;
                            }
                          },
                          pinTheme: PinTheme(
                            shape: PinCodeFieldShape.box,
                            borderRadius: BorderRadius.circular(5),
                            fieldHeight: 60,
                            fieldWidth: 50,
                            activeFillColor:
                            hasError ? Colors.orange : Colors.white,
                          ),
                          cursorColor: Colors.black,
                          animationDuration: Duration(milliseconds: 300),
                          textStyle: TextStyle(fontSize: 20, height: 1.6),
                        //  backgroundColor: Colors.blue.shade50,
                          enableActiveFill: true,
                          errorAnimationController: errorController,
                          controller: textEditingController,
                          keyboardType: TextInputType.number,
                          // boxShadows: [
                          //   BoxShadow(
                          //     offset: Offset(0, 1),
                          //     color: Colors.black12,
                          //     blurRadius: 10,
                          //   )
                          // ],
                          onCompleted:  (pin)async{
                            try{
                              await FirebaseAuth.instance.signInWithCredential(
                                  PhoneAuthProvider.credential(
                                      verificationId: verificationCode, smsCode: pin)).then((value)async{
                                if(value.user!=null){
                                  print("pass to home");
                                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>DoorSelection()));
                                }
                              });
                            } catch(e){
                              FocusScope.of(context).unfocus();
                              scaffoldKey.currentState.showSnackBar(SnackBar(content: Text("invilid OTP")));
                            }
                          },
                          // onTap: () {
                          //   print("Pressed");
                          // },
                          onChanged: (value) {
                            print(value);
                            setState(() {
                              currentText = value;
                            });
                          },
                          beforeTextPaste: (text) {
                            print("Allowing to paste $text");
                            //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                            //but you can show anything you want here, like your pop up saying wrong paste format or etc
                            return true;
                          },
                        )),
                  ),
               Padding(
                 padding: const EdgeInsets.symmetric(horizontal: 30.0),
                 child: Text(
                   hasError ? "*Please fill up all the cells properly" : "",
                   style: TextStyle(
                       color: Colors.red,
                       fontSize: 12,
                       fontWeight: FontWeight.w400),
                 ),
               ),
               SizedBox(
                 height: 20,
               ),
               RichText(
                 textAlign: TextAlign.center,
                 text: TextSpan(
                     text: "Didn't receive the code? ",
                     style: TextStyle(color: Colors.black54, fontSize: 15),
                     children: [
                       TextSpan(
                           text: " RESEND",
                           recognizer: onTapRecognizer,
                           style: TextStyle(
                               color: Color(0xFF91D3B3),
                               fontWeight: FontWeight.bold,
                               fontSize: 16))
                     ]),
               ),
               SizedBox(
                 height: 14,
               ),
               Container(
                 margin:
                 const EdgeInsets.symmetric(vertical: 16.0, horizontal: 30),
                 child: ButtonTheme(
                   height: 50,
                   child: FlatButton(
                     onPressed: () {
                       formKey.currentState.validate();
                       // conditions for validating
                       if (currentText.length != 6 || currentText != "towtow") {
                         errorController.add(ErrorAnimationType
                             .shake); // Triggering error shake animation
                         setState(() {
                           hasError = true;
                         });
                       } else {
                         setState(() {
                           hasError = false;
                           scaffoldKey.currentState.showSnackBar(SnackBar(
                             content: Text("Aye!!"),
                             duration: Duration(seconds: 2),
                           ));
                         });
                       }
                     },
                     child: Center(
                         child: InkWell(
                           onTap: (){
                            // phoneSignIn();
                           },
                           child: Text(
                             "VERIFY".toUpperCase(),
                             style: TextStyle(
                                 color: Colors.white,
                                 fontSize: 18,
                                 fontWeight: FontWeight.bold),
                           ),
                         )),
                   ),
                 ),
                 decoration: BoxDecoration(
                     color: Color(0xff007360),
                     borderRadius: BorderRadius.circular(20),
                     boxShadow: [
                       BoxShadow(
                           color: Colors.green.shade200,
                           offset: Offset(1, -2),
                           blurRadius: 5),
                       BoxShadow(
                           color: Colors.green.shade200,
                           offset: Offset(-1, 2),
                           blurRadius: 5)
                     ]),
               ),
               SizedBox(
                 height: 16,
               ),
               Row(
                 mainAxisAlignment: MainAxisAlignment.center,
                 children: <Widget>[
                   FlatButton(
                     child: Text("Clear"),
                     onPressed: () {
                       textEditingController.clear();
                     },
                   ),
                   FlatButton(
                     child: Text("Set Text"),
                     onPressed: () {
                       textEditingController.text = "123456";
                     },
                   ),
      ]
    )
                ],),
                )
          ],
        ),
      ),
    );
  }
}
