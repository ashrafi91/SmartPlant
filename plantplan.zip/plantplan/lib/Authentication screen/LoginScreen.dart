import 'dart:math';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:smartplant/BottomBarScreens/HomePage.dart';
import 'package:smartplant/Indoor&outdoor/doorSelection.dart';
import 'package:smartplant/plantscreen/firstpscreen.dart';

import 'OtpScreen.dart';
import 'SignUp.dart';
import 'forget password.dart';

class LoginScreen extends StatefulWidget {
  //const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  bool isPhone=true;
  bool checkedValue=false;
  bool mailvalidate=false;
  bool passvalidate=false;
  bool phonevalidate=false;
  bool isEnabled=false;
  bool passswordvisible=false;
  String otpToken;
  String phone;
  String error;
  TextEditingController emailEditingController = TextEditingController();
  TextEditingController passEditingController = TextEditingController();
  TextEditingController phoneEditingController = TextEditingController();
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp
    ]);
  }
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  FirebaseAuth _auth=FirebaseAuth.instance;
  //register through phone number
  Future<UserCredential> signInWithGoogle() async {
    // Trigger the authentication flow
    final GoogleSignInAccount googleUser = await GoogleSignIn().signIn();

    // Obtain the auth details from the request
    final GoogleSignInAuthentication googleAuth = await googleUser?.authentication;

    // Create a new credential
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth?.accessToken,
      idToken: googleAuth?.idToken,
    );

    // Once signed in, return the UserCredential
    return await FirebaseAuth.instance.signInWithCredential(credential).then((value) {
      Fluttertoast.showToast(
          msg: "LogIn Succesfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0
      );
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>HomePage()));
    });
  }
  String generateNonce([int length = 32]) {
    final charset =
        '0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._';
    final random = Random.secure();
    return List.generate(length, (_) => charset[random.nextInt(charset.length)])
        .join();
  }

  _signInWithEmailAndPassword() async {
    final User user = (await _auth.signInWithEmailAndPassword(
      email: emailEditingController.text,
      password: passEditingController.text,
    )).user;

    if (user != null) {
      Fluttertoast.showToast(
          msg: "LogIn Succesfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0
      );
      setState(() {
        print("User login Succesfullly with ${user.email}");
        Navigator.push(
            context,
            MaterialPageRoute(builder: (context) =>
                DoorSelection())
        );
      });
    } else {
      Fluttertoast.showToast(
          msg: "you are not register",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0
      );
      setState(() {
        _scaffoldKey.currentState.showSnackBar(SnackBar(
          content: Text(
            'Welcome',
          ),
          duration: Duration(seconds: 2),
        ));
        print("User not login");
      });
    }
  }
  void dispose() {
    emailEditingController.dispose();
    passEditingController.dispose();
    phoneEditingController.dispose();

    super.dispose();
  }
  String btnText="Request OTP";
  @override
  Widget build(BuildContext context) {
    var h=MediaQuery.of(context).size.height;
    var w=MediaQuery.of(context).size.width;

  return  Scaffold(
        body: Container(
          height: double.infinity,
          width: double.infinity,
          decoration: BoxDecoration(
            color:  Color(0xffFFFFFF),
            // image:  DecorationImage(
            //   image: AssetImage('assets/bak.png'),
            //   fit: BoxFit.fill,
            //
            // ),
          ),
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: h*0.045,),
                  // SizedBox(height: h*0.07,),
                  Text('Sign in Account',style: TextStyle(color: Color(0xff202D50),fontWeight:
                  FontWeight.w700,fontSize: 24,fontStyle: FontStyle.normal),),
                  SizedBox(height: 5,),
                  Text('Hello, welcome back to Smart Plants',style:
                  TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 14),),
                  SizedBox(height: 15,),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 52,
                    decoration: BoxDecoration(
                      color:Color(0xffF7F6FB),

                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        GestureDetector(
                          onTap: (){
                            if(isPhone==true){
                              setState(() {
                               btnText="Sign In";
                                isPhone=false;
                              });
                            }
                            else{
                              setState(() {
                                btnText="Request OTP";
                                isPhone=true;
                              });
                            }
                          },
                          child: Container(
                          //  height: 44,
                            width: MediaQuery.of(context).size.width*0.4,
                            decoration: BoxDecoration(
                              color:isPhone?  Color(0xffffffff):Color(0xffF7F6FB),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Center(
                              child: Text('Phone',style: TextStyle(color: Color(0xff3D4864),
                                  fontWeight: FontWeight.w600),),
                            ),
                          ),
                        ),
                        SizedBox(width: 20,),
                        GestureDetector(
                          onTap: (){
                            if(isPhone==false){

                              setState(() {
                                btnText="Request OTP";
                                isPhone=true;
                              });
                            }
                            else{
                              setState(() {
                                btnText="Sign In";
                                isPhone=false;
                              });
                            }
                          },
                          child: Container(
                    //        height: 44,
                              width: MediaQuery.of(context).size.width*0.4,
                            decoration: BoxDecoration(
                              color:isPhone?  Color(0xffF7F6FB):Color(0xffffffff),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Center(
                              child: Text('Email',style: TextStyle(color: Color(0xff3D4864),
                                  fontWeight: FontWeight.w600),),
                            ),
                          ),
                        ),

                      ],
                    ),
                  ),
                  SizedBox(height: 5,),
               //   Divider(indent: 50,endIndent: 50,color: Colors.grey,),

                  isPhone?
                  Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: Container(
                     // height: h*0.08,
                      child: TextField(
                        keyboardType: TextInputType.phone,
                        controller: phoneEditingController,
                        style: TextStyle(color: Color(0xff3D4864)),
                        decoration: InputDecoration(

                            fillColor: Color(0x29FFFFFF),
                            prefixIcon: Padding(padding: EdgeInsets.all(15),
                                child: Text('+66',style: TextStyle(color:Color(0xff3D4864)),)),
                            filled: true,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14.0),
                                borderSide: new BorderSide(color: Color(0xff3D4864))
                            ),
                            enabledBorder:  OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide:  BorderSide(color: Color(0xff3D4864), width: 0.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide:  BorderSide(color: Color(0xff3D4864), width: 0.0),
                            ),
                            labelText: 'Phone*',
                            labelStyle: TextStyle(color: Color(0xff3D4864)),
                            errorText: phonevalidate?"Phone number required*":null
                        ),
                      ),
                    ),
                  )
                      : Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: Container(
                    //  height: h*0.08,
                      child: TextField(
                        keyboardType: TextInputType.emailAddress,
                        controller: emailEditingController,
                        style: TextStyle(color: Color(0xff3D4864)),
                        decoration: InputDecoration(
                            fillColor: Color(0x29FFFFFF),
                            filled: true,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14.0),
                        borderSide: new BorderSide(color: Color(0xff3D4864))
                            ),
                            enabledBorder:  OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide:  BorderSide(color: Color(0xff3D4864), width: 0.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide:  BorderSide(color: Color(0xff3D4864), width: 0.0),
                            ),
                            labelText: 'Email*',
                            labelStyle: TextStyle(color: Color(0xff3D4864)),
                          errorText: mailvalidate?"email required*":null
                        ),
                      ),
                    ),
                  ),


               isPhone? Container():Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: Container(
                    //  height: h*0.08,
                      child: TextField(
                        controller: passEditingController,
                        onChanged: (val){
                          setState(() {
                            isEnabled=true;
                          });
                        },
                        style: TextStyle(color: Color(0xff202D50)),
                        obscureText: !passswordvisible,
                        decoration: InputDecoration(
                            fillColor: Color(0x29FFFFFF),
                            filled: true,
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(14.0),
                                borderSide: new BorderSide(color: Color(0xff3D4864))
                            ),
                            enabledBorder:  OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide:  BorderSide(color:Color(0xff3D4864), width: 0.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(14),
                              borderSide:  BorderSide(color: Color(0xff3D4864), width: 0.0),
                            ),
                            labelText: 'Password',
                            labelStyle: TextStyle(color: Color(0xff3D4864)),
                            errorText: passvalidate?"invild Password":null,
                          suffixIcon: IconButton(
                            onPressed: (){
                              setState(() {
                                passswordvisible=!passswordvisible;
                              });

                            },
                            icon:Icon( passswordvisible?Icons.visibility:Icons.visibility_off,color: Theme.of(context).primaryColorDark,),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // Theme(
                  //   data: ThemeData(unselectedWidgetColor: Colors.white),
                  //   child: CheckboxListTile(
                  //     title: Text("remember me",style: TextStyle(color: Colors.white),),
                  //     value: checkedValue,
                  //     activeColor: Colors.grey,
                  //     onChanged: (newValue) {
                  //       setState(() {
                  //         checkedValue = newValue;
                  //       });
                  //     },
                  //     controlAffinity: ListTileControlAffinity.leading,  //  <-- leading Checkbox
                  //   ),
                  // ),
                  SizedBox(height: 20,),
                  isPhone? Container():
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>ForgetPassword()));
                        },
                        child: Text(' forgot password',style: TextStyle(fontWeight: FontWeight.w400,color: Color(0xff6EC350),fontSize: 16,decoration: TextDecoration.underline,),)),
                  ),
                  GestureDetector(
                    onTap: (){

                      //login();
                     if(isPhone==true) {
                       setState(() {
                         phoneEditingController.text.isEmpty
                             ? phonevalidate = true
                             : phonevalidate = false;
                       });
                       if (phoneEditingController.text.isNotEmpty) {

                         Navigator.push(
                             context,
                             MaterialPageRoute(builder: (context) =>
                                 OtpScreen(phoneNumber: phoneEditingController.text,username: "default",))
                         );
                       }
                     }
                     else{
                       setState(()
                       {
                         emailEditingController.text.isEmpty ? mailvalidate = true : phonevalidate = false;
                         passEditingController.text.isEmpty ? passvalidate = true : passvalidate = false;
                       });
                       if(emailEditingController.text.isNotEmpty&& passEditingController.text.isNotEmpty) {
                         _signInWithEmailAndPassword();
                       }
                       // Navigator.push(
                       //     context,
                       //     MaterialPageRoute(builder: (context) => firstplant())
                       // );
                     }
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(top: 12.0),
                      child: Container(
                        height: h*0.08,
                        decoration: BoxDecoration(
                          color:Color(0xff007360),

                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Center(
                          child: Text(btnText,style: TextStyle(color: Colors.white,fontSize: 14,fontWeight: FontWeight.w600),),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 30,),
                  isPhone? Container():   Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(height: 1.0,width:w*0.2,color: Colors.black12,),
                      Text("  or Sign in with ",style: TextStyle(color: Color(0xff3D4864),fontSize: 14,
                          fontWeight: FontWeight.w400),),
                      Container(height: 1.0,width:w*0.2,color: Colors.black12,),
                    ],
                  ),
              SizedBox(height: 30,),
                  isPhone? Container():   RaisedButton(
                elevation: 5.0,
                onPressed: ()
                {
                  signInWithGoogle();
                  // if(_key1.currentState.validate() && _key2.currentState.validate()){
                  //   databaseLogin();
                  // }
                  },
                padding: EdgeInsets.all(15.0),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                color: Colors.white,
                child:
                      Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                        children:[
                          Image.asset("assets/icons/icons_google.png",width: 24,height: 24,),
                          Text(" Google",style: TextStyle(color: Colors.black,fontSize: 14,
                              fontWeight: FontWeight.w600),),
                      ]),
                    ),
                  SizedBox(height: 30,),
                  isPhone? Container():  RaisedButton(
                    elevation: 5.0,
                    onPressed: ()
                    {
                      // if(_key1.currentState.validate() && _key2.currentState.validate()){
                      //   databaseLogin();
                      // }
                    },
                    padding: EdgeInsets.all(15.0),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                    color: Colors.white,
                    child:
                    Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children:[
                          Image.asset("assets/icons/Apple.png",width: 24,height: 24,),
                          Text(" Apple",style: TextStyle(color: Colors.black,fontSize: 14,
                              fontWeight: FontWeight.w600),),
                        ]),
                  ),
                  SizedBox(height: 30,),
                  isPhone? Container():  Center(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: InkWell(
                    onTap: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SignUp()),
                      );
                    },
                    child: RichText(text: TextSpan(
                        text: "Not register yet?",
                        style: TextStyle(
                            fontSize: 14,fontWeight: FontWeight.w600,
                            fontStyle: FontStyle.normal,color: Color(0xa8cec8c8)),
                        children: [
                          TextSpan(text: " Register Here",style:TextStyle(
                              fontSize: 14,fontWeight: FontWeight.w600,
                              fontStyle: FontStyle.normal,color: Colors.black)   ),
                        ]
                    )     ),
                  ),
                ),
              )


                  // Row(
                  //   mainAxisAlignment: MainAxisAlignment.center,
                  //   children: [
                  //     GestureDetector(
                  //       onTap: (){
                  //         // Navigator.push(
                  //         //   context,
                  //         //   MaterialPageRoute(builder: (context) => RegisterPage()),
                  //         // );
                  //       },
                  //       child: Text('Register',
                  //         style: TextStyle(fontWeight: FontWeight.w400,color: Color(0xff6EC350),fontSize: 16,decoration: TextDecoration.underline,),),
                  //     ),
                  //     Text(' or ',style: TextStyle(fontWeight: FontWeight.w400,color: Colors.white,fontSize: 16),),
                  //     Text(' forgot password',style: TextStyle(fontWeight: FontWeight.w400,color: Color(0xff6EC350),fontSize: 16,decoration: TextDecoration.underline,),)
                  //   ],
                  // )


                ],
              ),
            ),
          ),
        )
    );
    }
}
