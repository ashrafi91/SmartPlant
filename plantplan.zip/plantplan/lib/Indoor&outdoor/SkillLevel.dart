import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import 'CommitLevel.dart';

class Skills extends StatefulWidget {
   Skills({Key key,this.door}) : super(key: key);
 String door;
  @override
  _DoorSelectionState createState() => _DoorSelectionState();
}

class _DoorSelectionState extends State<Skills> {

  initState() {
    super.initState();
netcheck();
  }
  netcheck()async{
    try {
      final result = await InternetAddress.lookup('example.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {

        print('connected');

      }
    } on SocketException catch (_) {

      print('not connected');
    }
  }
  final FirebaseAuth auth=FirebaseAuth.instance;
  String level="";
 String Stars="";
  DatabaseReference databaseReference=new FirebaseDatabase().reference();
  void createRecord() {
    final User user=auth.currentUser;
    databaseReference.child("User").child(user.uid).child("skill").set(level);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff007360),
      appBar: AppBar(
        backgroundColor: Color(0xff007360),
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        elevation: 0.0,
        title: Text("Setup Your Account",style: TextStyle(
          color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,),),
        centerTitle: true,
      ),
      body: Align(
        alignment: Alignment.bottomLeft,
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height*0.85,
          decoration: BoxDecoration(
              color: Color(0xffffffff),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))
          ),
          child: Column(
            children: [
              SizedBox(height: 30,),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xffF0F0F0),width: 30,),
                ],
              ),
              SizedBox(height: 40,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('3/4 (Skills)',style:
                  TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 9),),
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('Skill Level',style: TextStyle(color: Color(0xff202D50),fontWeight:
                  FontWeight.w700,fontSize: 24,fontStyle: FontStyle.normal),),
                ),
              ),
              SizedBox(height: 5,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('How skilled are you at taking care of planets?',style:
                  TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 14),),
                ),
              ),
              SizedBox(height: 20,),
              Expanded(
                  child: SingleChildScrollView(
                    child: Container(
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: InkWell(
                                    onTap: (){
                                      setState(() {
                                        level="hopeless";
                                      });
                                      createRecord();
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => Commit(level: level,))
                                    );
                                      },
                                    child: Container(
                                      width: MediaQuery.of(context).size.width*0.45,
                                      height: MediaQuery.of(context).size.height/4,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.circular(10)),
                                          border: Border.all(color: Color(
                                              0xffeee9e9)),
                                        color: Color(0xffffffff),
                                      ),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Image.asset("assets/icons/firstlavel.png"),
                                          SizedBox(height: 20,),
                                          Text('Hopeless',style:
                                          TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w600,fontSize: 16),),
                                          SizedBox(height: 20,),
                                      RatingBar.builder(
                                        minRating: 1,
                                        itemSize: 18,
                                        direction: Axis.horizontal,
                                        allowHalfRating: true,
                                        itemCount: 5,
                                        itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                        itemBuilder: (context, _) => Icon(
                                          Icons.star,
                                          color: Colors.black,
                                        ),
                                        onRatingUpdate: (rating) {
                                          setState(() {
                                            Stars=rating.toString();
                                          });
                                          print(rating);
                                        },
                                      )
                                        ],
                                      ),
                                      ),
                                  ),
                                ),
                              ),
                              Expanded(
                                  child:  Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: InkWell(

                                      onTap: (){
                                        setState(() {
                                          level="Biggner";
                                        });
                                        createRecord();
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(builder: (context) => Commit(level: level,))
                                      );},
                                      child: Container(
                                        width: MediaQuery.of(context).size.width*0.45,
                                        height: MediaQuery.of(context).size.height/4,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.all(Radius.circular(10)),
                                          border: Border.all(color: Color(
                                              0xffeee9e9)),
                                          color: Color(0xffffffff),
                                        ),
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Image.asset("assets/icons/bignarlavel.png"),
                                            SizedBox(height: 20,),
                                            Text('Begineer',style:
                                            TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w600,fontSize: 16),),
                                            SizedBox(height: 20,),
                                            RatingBar.builder(
                                              minRating: 1,
                                              itemSize: 18,
                                              direction: Axis.horizontal,
                                              allowHalfRating: true,
                                              itemCount: 5,
                                              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                              itemBuilder: (context, _) => Icon(
                                                Icons.star,
                                                color: Colors.black,
                                              ),
                                              onRatingUpdate: (rating) {
                                                setState(() {
                                                  Stars=rating.toString();
                                                });
                                                print(rating);
                                              },
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: InkWell(
                                    onTap: (){
                                      setState(() {
                                        level="expirence";
                                      });
                                      createRecord();
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => Commit(level: level,))
                                    );},
                                    child: Container(
                                      width: MediaQuery.of(context).size.width*0.45,
                                      height: MediaQuery.of(context).size.height/4,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.circular(10)),
                                        border: Border.all(color: Color(
                                            0xffeee9e9)),
                                        color: Color(0xffffffff),
                                      ),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Image.asset("assets/icons/expirencelevel.png"),
                                          SizedBox(height: 20,),
                                          Text('Experienced',style:
                                          TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w600,fontSize: 16),),
                                          SizedBox(height: 20,),
                                          RatingBar.builder(
                                            initialRating: 1,
                                            minRating: 1,
                                            itemSize: 18,
                                            direction: Axis.horizontal,
                                            allowHalfRating: true,
                                            itemCount: 5,
                                            itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                            itemBuilder: (context, _) => Icon(
                                              Icons.star,
                                              color: Colors.black,
                                            ),
                                            onRatingUpdate: (rating) {
                                              setState(() {
                                                Stars=rating.toString();
                                              });
                                              print(rating);
                                            },
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Expanded(
                                child:  Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: InkWell(
                                    onTap: (){
                                      setState(() {
                                        level="skill";
                                      });
                                      createRecord();
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => Commit(level: level,))
                                    );},
                                    child: Container(
                                      width: MediaQuery.of(context).size.width*0.45,
                                      height: MediaQuery.of(context).size.height/4,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.circular(10)),
                                        border: Border.all(color: Color(
                                            0xffeee9e9)),
                                        color: Color(0xffffffff),
                                      ),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Image.asset("assets/icons/skillslevel.png"),
                                          SizedBox(height: 20,),
                                          Text('Skilled',style:
                                          TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w600,fontSize: 16),),
                                          SizedBox(height: 20,),
                                          RatingBar.builder(
                                            minRating: 1,
                                            itemSize: 18,
                                            direction: Axis.horizontal,
                                            allowHalfRating: true,
                                            itemCount: 5,
                                            itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                            itemBuilder: (context, _) => Icon(
                                              Icons.star,
                                              color: Colors.black,
                                            ),
                                            onRatingUpdate: (rating) {
                                              setState(() {
                                                Stars=rating.toString();
                                              });
                                              print(rating);
                                            },
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: InkWell(
                              onTap: (){
                                setState(() {
                                  level="expert";
                                });
                                createRecord();
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => Commit(level: level,))
                              );},
                              child: Container(
                                width: MediaQuery.of(context).size.width*0.45,
                                height: MediaQuery.of(context).size.height/4,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.all(Radius.circular(10)),
                                  border: Border.all(color: Color(
                                      0xffeee9e9)),
                                  color: Color(0xffffffff),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset("assets/icons/expert.png"),
                                    SizedBox(height: 20,),
                                    Text('Master',style:
                                    TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w600,fontSize: 16),),
                                    SizedBox(height: 20,),
                                    RatingBar.builder(
                                      minRating: 1,
                                      itemSize: 18,
                                      direction: Axis.horizontal,
                                      allowHalfRating: true,
                                      itemCount: 5,
                                      itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                                      itemBuilder: (context, _) => Icon(
                                        Icons.star,
                                        color: Colors.black,
                                      ),
                                      onRatingUpdate: (rating) {
                                        Stars=rating.toString();
                                        print(rating);
                                      },
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ))
            ],
          ),
        ),
      ),
    );
  }
}
