// import 'package:flutter/material.dart';
// import 'package:flutter_rating_bar/flutter_rating_bar.dart';
// import 'package:geocoding/geocoding.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:smartplant/plantscreen/ConnectPlant.dart';
//
// class LocationScreen extends StatefulWidget {
//   //const DoorSelection({Key? key}) : super(key: key);
//
//   @override
//   _DoorSelectionState createState() => _DoorSelectionState();
// }
//
// class _DoorSelectionState extends State<LocationScreen> {
//   Position _currentPosition;
//   String _currentAddress;
//   _getCurrentLocation() {
//     Geolocator
//         .getCurrentPosition(desiredAccuracy: LocationAccuracy.best, forceAndroidLocationManager: true)
//         .then((Position position) {
//       setState(() {
//         _currentPosition = position;
//         _getAddressFromLatLng();
//       });
//     }).catchError((e) {
//       print(e);
//     });
//   }
//   _getAddressFromLatLng() async {
//     try {
//       List<Placemark> placemarks = await placemarkFromCoordinates(
//           _currentPosition.latitude,
//           _currentPosition.longitude
//       );
//
//       Placemark place = placemarks[0];
//
//       setState(() {
//         _currentAddress = "${place.locality}, ${place.postalCode}, ${place.country}";
//       });
//     } catch (e) {
//       print(e);
//     }
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Color(0xff007360),
//       appBar: AppBar(
//         backgroundColor: Color(0xff007360),
//         iconTheme: IconThemeData(
//           color: Colors.black, //change your color here
//         ),
//         elevation: 0.0,
//         title: Text("Your Location",style: TextStyle(
//           color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,),),
//         centerTitle: true,
//       ),
//       body: Align(
//         alignment: Alignment.bottomLeft,
//         child: Container(
//           width: MediaQuery.of(context).size.width,
//           height: MediaQuery.of(context).size.height*0.85,
//           decoration: BoxDecoration(
//               color: Color(0xffffffff),
//               borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))
//           ),
//           child: Column(
//             children: [
//               SizedBox(height: 30,),
//
//               Padding(
//                 padding: const EdgeInsets.only(left:20.0),
//                 child: Align(
//                   alignment: Alignment.topLeft,
//                   child: Text('Why It’s Important?',style: TextStyle(color: Color(0xff202D50),fontWeight:
//                   FontWeight.w700,fontSize: 24,fontStyle: FontStyle.normal),),
//                 ),
//               ),
//               SizedBox(height: 5,),
//               Padding(
//                 padding: const EdgeInsets.only(left:20.0),
//                 child: Align(
//                   alignment: Alignment.topLeft,
//                   child: Text('If you allow this app to know about your location\n'
//                       ' this app can give you suggestion depending on\n your Climate',style:
//                   TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 14),),
//                 ),
//               ),
//               SizedBox(height: 20,),
//               SingleChildScrollView(
//                 child: Expanded(
//                     child: Align(
//                       alignment: Alignment.center,
//                       child: Container(
//                   child:Column(
//                     children: [
//                      // Image.asset("assets/icons/Address-cuate 1.png"),
//                       if (_currentAddress != null) Text(
//                           _currentAddress
//                       ),
//                     ],
//                   )
//                 ),
//                     )
//                 ),
//               ),
//               Expanded(
//                 child: Container(),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(20.0),
//                 child: GestureDetector(
//                   onTap: (){
//                     _getCurrentLocation();
//
//
//                   },
//                   child: Padding(
//                     padding: const EdgeInsets.only(top: 12.0),
//                     child: Container(
//                       height: MediaQuery.of(context).size.height*0.08,
//                       decoration: BoxDecoration(
//                         color: Color(0xff007360),
//
//                         borderRadius: BorderRadius.circular(20),
//                       ),
//                       child: Center(
//                         child: Text("Continue",style: TextStyle(
//                             color: Colors.white,fontSize: 14,fontWeight: FontWeight.w600),),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//               InkWell(
//                 onTap: (){
//                   Navigator.push(
//                       context,
//                       MaterialPageRoute(builder: (context) => ConnectPlant())
//                   );
//                 },
//                 child: Text('Skip for now?',style: TextStyle(color: Color(0xff202D50),fontWeight:
//                 FontWeight.w700,fontSize: 14,fontStyle: FontStyle.normal),),
//               ),
//               SizedBox(height: 20,)
//             ],
//
//           ),
//         ),
//       ),
//     );
//   }
// }
