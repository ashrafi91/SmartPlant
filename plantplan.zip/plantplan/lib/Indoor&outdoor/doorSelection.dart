import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'SkillLevel.dart';

class DoorSelection extends StatefulWidget {
  //const DoorSelection({Key? key}) : super(key: key);

  @override
  _DoorSelectionState createState() => _DoorSelectionState();
}

class _DoorSelectionState extends State<DoorSelection> {
  final FirebaseAuth auth=FirebaseAuth.instance;
   String doorno="";
  DatabaseReference databaseReference=new FirebaseDatabase().reference();
  void createRecord() {
    final User user=auth.currentUser;
    databaseReference.child("User").child(user.uid).child("door").set(doorno);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff007360),
     appBar: AppBar(
        backgroundColor: Color(0xff007360),
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        elevation: 0.0,
        title: Text("Setup Your Account",style: TextStyle(
          color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,),),
        centerTitle: true,
      ),
      body: Align(
        alignment: Alignment.bottomLeft,
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height*0.85,
          decoration: BoxDecoration(
              color: Color(0xffffffff),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))
          ),
          child: Column(
            children: [
              SizedBox(height: 30,),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xffF0F0F0),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xffF0F0F0),width: 30,),
                ],
              ),
              SizedBox(height: 40,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('2/4 (Introduction)',style:
                  TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 9),),
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('Indoor or Outdoor',style: TextStyle(color: Color(0xff202D50),fontWeight:
                  FontWeight.w700,fontSize: 24,fontStyle: FontStyle.normal),),
                ),
              ),
              SizedBox(height: 5,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('Would you like help with plants indoor, outdoor\n or both?',style:
                  TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 14),),
                ),
              ),
              SizedBox(height: 20,),
              Expanded(
                
             child: SingleChildScrollView(
               child: Column(
                 children: [
                   Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: InkWell(
                        onTap: (){

                          setState(() {
                            doorno="Indoor";
                          });
                          createRecord();
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => Skills(door: doorno,))
                        );},
                        child: Container(
                          width: MediaQuery.of(context).size.width,
                          height: 138,
                          decoration: BoxDecoration(
                              image:DecorationImage(
                                  image: AssetImage("assets/icons/indoor.png")
                              ) ,
                              // color: Color(0xffD5E7CF),
                              // borderRadius: BorderRadius.all(Radius.circular(10))
                          ),

                        ),
                      ),
                    ),
                
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: InkWell(
                    onTap: (){

                      setState(() {
                        doorno="Outdoor";
                      });
                      createRecord();
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Skills(door: doorno,))
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: 138,
                      decoration: BoxDecoration(
                        image:DecorationImage(
                            image: AssetImage("assets/icons/outdoor.png")
                        ) ,
                        // color: Color(0xffD5E7CF),
                        // borderRadius: BorderRadius.all(Radius.circular(10))
                      ),

                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: InkWell(
                    onTap: (){

                      setState(() {
                        doorno="InOutdoor";
                      });
                      createRecord();
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Skills(door: doorno ,))
                      );
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      height: 138,
                      decoration: BoxDecoration(
                        image:DecorationImage(
                            image: AssetImage("assets/icons/inoutdoor.png")
                        ) ,
                        // color: Color(0xffD5E7CF),
                        // borderRadius: BorderRadius.all(Radius.circular(10))
                      ),
                      // child: Row(
                      //   children: [
                      //     Padding(
                      //         padding: EdgeInsets.all(5),
                      //     child: Container(
                      //       width: 120,
                      //       height: 120,
                      //       decoration: BoxDecoration(
                      //           color: Color(0xff3c7b27),
                      //           image:DecorationImage(
                      //             image: AssetImage("assets/icons/Intersect.png")
                      //           ) ,
                      //           borderRadius: BorderRadius.all(Radius.circular(10))
                      //       ),
                      //     ),
                      //     ),
                      //     Column(
                      //       mainAxisAlignment: MainAxisAlignment.start,
                      //       children: [
                      //         Align(
                      //           alignment: Alignment.topLeft,
                      //           child: Padding(
                      //               padding: EdgeInsets.all(5),
                      //             child: Text('Indoor',style:
                      //             TextStyle(color: Color(0xff202D50),fontWeight: FontWeight.w600,fontSize: 16),)
                      //           ),
                      //         ),
                      //         Padding(
                      //             padding: EdgeInsets.all(1),
                      //             child: Text('For indoor plant care',style:
                      //             TextStyle(color: Color(0xff202D50),fontWeight: FontWeight.w400,fontSize: 14),)
                      //         ),
                      //       ],
                      //     )
                      //   ],
                      // ),
                    ),
                  ),
                ),
                 ],
               ),
             ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
