
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:smartplant/plantscreen/ConnectPlant.dart';

import 'LocationScreen.dart';

class Commit extends StatefulWidget {
   Commit({Key key,this.level}) : super(key: key);
 String level;
  @override
  _DoorSelectionState createState() => _DoorSelectionState();
}

class _DoorSelectionState extends State<Commit> {
  bool hclickcolor=false;
  bool mclickcolor=false;
  bool clickcolor=false;
  String step="one";
  initState(){
    hclickcolor=false;
     mclickcolor=false;
     clickcolor=true;
    super.initState();}
  final FirebaseAuth auth=FirebaseAuth.instance;
  DatabaseReference databaseReference=new FirebaseDatabase().reference();
  void createRecord() {
    final User user=auth.currentUser;
    databaseReference.child("User").child(user.uid).child("step").set(step);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff007360),
      appBar: AppBar(
        backgroundColor: Color(0xff007360),
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        elevation: 0.0,
        title: Text("Setup Your Account",style: TextStyle(
          color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,),),
        centerTitle: true,
      ),
      body: Align(
        alignment: Alignment.bottomLeft,
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height*0.85,
          decoration: BoxDecoration(
              color: Color(0xffffffff),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))
          ),
          child: Column(
            children: [
              SizedBox(height: 30,),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                  SizedBox(width: 10,),
                  Container(height: 5,color: Color(0xff007360),width: 30,),
                ],
              ),
              SizedBox(height: 40,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('4/4 (Commitments)',style:
                  TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 9),),
                ),
              ),
              SizedBox(height: 10,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('Commitment Level',style: TextStyle(color: Color(0xff202D50),fontWeight:
                  FontWeight.w700,fontSize: 24,fontStyle: FontStyle.normal),),
                ),
              ),
              SizedBox(height: 5,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('How much time and energy do you want to spend\non your plants?',style:
                  TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 14),),
                ),
              ),
              SizedBox(height: 20,),
              Expanded(child:
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: InkWell(
                        onTap: (){
                          setState(() {
                            hclickcolor=false;
                            mclickcolor=false;
                            clickcolor=true;
                          });
                          step="one";
                        },
                        child: Container(
                          width: 100,
                          height:115,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            border: Border.all(color:clickcolor? Color(0xff007360):Color(
                                0x9fe3dada)),
                            color: Color(0xffffffff),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                            Image.asset(clickcolor?"assets/icons/firstpercent.png":"assets/icons/zeroeleve.png"),
                              SizedBox(height: 20,),
                              Text('Low',style:
                              TextStyle(color:clickcolor? Color(0xff3D4864):Color(0xffD9D9D9),fontWeight: FontWeight.w600,fontSize: 16),),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: InkWell(
                        onTap: (){
                          setState(() {
                            hclickcolor=false;
                            mclickcolor=true;
                            clickcolor=false;
                          });
                        },
                        child: Container(
                          width: 100,
                          height:115,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            border: Border.all(color: mclickcolor? Color(0xff007360):Color(
                                0x9fe3dada)),
                            color: Color(0xffffffff),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset(mclickcolor?"assets/icons/midleveltrue.png":"assets/icons/secondnotselect.png"),
                              SizedBox(height: 20,),
                              Text('Medium',style:
                              TextStyle(color:mclickcolor? Color(0xff3D4864):Color(0xffD9D9D9),fontWeight: FontWeight.w600,fontSize: 16),),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: InkWell(
                        onTap: (){
                          setState(() {
                            hclickcolor=true;
                            mclickcolor=false;
                            clickcolor=false;
                          });
                      },
                        child: Container(
                          width: 100,
                          height:115,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(10)),
                            border: Border.all(color: hclickcolor? Color(0xff007360):Color(
                                0x9fe3dada)),
                            color: Color(0xffffffff),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset(hclickcolor?"assets/icons/highleve2.png":"assets/icons/thrdlevel.png"),
                              SizedBox(height: 20,),
                              Text('High',style:
                              TextStyle(color:hclickcolor? Color(0xff3D4864):Color(0xffD9D9D9),fontWeight: FontWeight.w600,fontSize: 16),),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              )),
              Expanded(
                child: Container(),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: GestureDetector(
                  onTap: (){
                    createRecord();
                      Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ConnectPlant())
                      );

                  },
                  child: Padding(
                    padding: const EdgeInsets.only(top: 12.0),
                    child: Container(
                      height: MediaQuery.of(context).size.height*0.08,
                      decoration: BoxDecoration(
                        color: Color(0xff007360),

                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Center(
                        child: Text("Continue",style: TextStyle(
                            color: Colors.white,fontSize: 14,fontWeight: FontWeight.w600),),
                      ),
                    ),
                  ),
                ),
              ),
            ],

          ),
        ),
      ),
    );
  }
}
