import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:smartplant/Authentication%20screen/LoginScreen.dart';
import 'package:smartplant/DashBoard/MainBoard.dart';
class firstplant extends StatefulWidget {
 // const firstplant({Key? key}) : super(key: key);

  @override
  _firstplantState createState() => _firstplantState();
}

class _firstplantState extends State<firstplant> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.bottom]);
    return Scaffold(
      body: Container(
        color: Color(0xff007360),
        child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: MediaQuery.of(context).size.height*0.8,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color(0xffffffff),
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(20),bottomRight: Radius.circular(20))
              ),
              child: Column(
                children: [
                  Image.asset("assets/icons/backfirstplant.png"),
                  Padding(
                    padding: const EdgeInsets.only(left:10.0,right: 10.0),
                    child: RichText(text: TextSpan(
                text: "The Sustainable,Smart way to",
                 style: TextStyle(
                fontSize: 24,fontWeight: FontWeight.w700,fontStyle: FontStyle.normal,color: Colors.black),
                children: [
                TextSpan(text: "Take Care ",style:TextStyle(
                    fontSize: 24,fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,color: Colors.green)   ),
                    TextSpan(text: "of your plants ",style:TextStyle(
                    fontSize: 24,fontWeight: FontWeight.w700,
                    fontStyle: FontStyle.normal,color: Colors.black)   ),
                 ]
                    )     ),
                  )
                ],
              ),
            ),
            InkWell(
              child: Container(
                height: MediaQuery.of(context).size.height*0.2,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                     InkWell(

                          onTap: (){
                          Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => MainBoard())
                          );
              },
                       child: Padding(
                         padding: const EdgeInsets.only(top:28.0),
                         child: Container(
                          width: MediaQuery.of(context).size.width*0.8,
                          height: 50,
                          decoration: BoxDecoration(
                            color:Colors.black ,
                              // gradient: LinearGradient(
                              //     end: Alignment.topLeft,
                              //     begin: Alignment.topRight,
                              //     colors: [
                              //       Colors.lightBlueAccent,
                              //       Colors.purpleAccent,
                              //
                              //     ]
                              // ),
                              borderRadius: BorderRadius.all(Radius.circular(20))
                          ),
                          child: Center(child: Text("Get Start With SmartPlant",
                            style: TextStyle(color: Colors.white,
                                fontSize: 14,fontWeight: FontWeight.w600),)),
                    ),
                       ),
                     ),
                     Padding(
                       padding: const EdgeInsets.only(bottom: 10),
                       child: InkWell(
                         onTap: (){
                           Navigator.push(
                             context,
                             MaterialPageRoute(builder: (context) => LoginScreen()),
                           );
                         },
                         child: RichText(text: TextSpan(
                              text: "Already a member?",
                              style: TextStyle(
                                  fontSize: 14,fontWeight: FontWeight.w600,
                                  fontStyle: FontStyle.normal,color: Color(0x66ffffff)),
                              children: [
                                TextSpan(text: " Sign in Here",style:TextStyle(
                                    fontSize: 14,fontWeight: FontWeight.w600,
                                    fontStyle: FontStyle.normal,color: Colors.white)   ),
                              ]
                          )     ),
                       ),
                     ),

                  ],
                ),

              ),
            )
          ],
        ),
      ),
    );
  }
}
