import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:smartplant/BottomBarScreens/HomePage.dart';
// import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:smartplant/DashBoard/MainBoard.dart';
import 'package:smartplant/DashBoard/MainSecond.dart';

class ConnectPlant extends StatefulWidget {
  //const DoorSelection({Key? key}) : super(key: key);

  @override
  _DoorSelectionState createState() => _DoorSelectionState();
}

class _DoorSelectionState extends State<ConnectPlant> {
  String dfaultba="unknown";
  final FirebaseAuth auth=FirebaseAuth.instance;
  DatabaseReference databaseReference=new FirebaseDatabase().reference();
  void createRecord() {
    final User user=auth.currentUser;
    databaseReference.child("User").child(user.uid).child("barcode").set(dfaultba);
  }
 Future<void> scanBarCode() async{
   try {
     final barcode = await FlutterBarcodeScanner.scanBarcode(
         "#ff6666",
         "cancel",
         true,
         ScanMode.BARCODE);
     if (!mounted) return;
     setState(() {
       this.dfaultba = barcode;
     });
   } on PlatformException{
     dfaultba="faild to get platform version";
   }

 }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff007360),
      appBar: AppBar(
        backgroundColor: Color(0xff007360),
        iconTheme: IconThemeData(
          color: Colors.black, //change your color here
        ),
        elevation: 0.0,
        title: Text("Connect Your Account",style: TextStyle(
          color: Colors.black,fontSize: 18,fontWeight: FontWeight.w700,),),
        centerTitle: true,
      ),
      body: Align(
        alignment: Alignment.bottomLeft,
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height*0.85,
          decoration: BoxDecoration(
              color: Color(0xffffffff),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(40),topRight: Radius.circular(40))
          ),
          child: Column(
            children: [
              SizedBox(height: 30,),

              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('Connect Your Planter Account',style: TextStyle(color: Color(0xff202D50),fontWeight:
                  FontWeight.w700,fontSize: 24,fontStyle: FontStyle.normal),),
                ),
              ),
              SizedBox(height: 5,),
              Padding(
                padding: const EdgeInsets.only(left:20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text('Hey Nadeem now you can connect your\n'
                      ' planter account with smart plant. Scan this QR\n'
                      ' code from your planter app.',style:
                  TextStyle(color: Color(0xff3D4864),fontWeight: FontWeight.w400,fontSize: 14),),
                ),
              ),
              SizedBox(height: 20,),

              Expanded(
                child: FlatButton(
                  child: Text("Click me",style: TextStyle(color: Colors.black,fontSize: 16),),
                  onPressed:()=>scanBarCode(),
                )
              ),
              Expanded(
                flex: 1,
                child: Center(
                child: Column(
                  children: [
                    Text(
                      "$dfaultba",
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.black
                      ),
                    ),
                    GestureDetector(
                      onTap: (){
                      if(!(dfaultba=="unknown")) {
                        createRecord();
                        Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => HomePage())
                        );
                      }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Container(
                          height: MediaQuery.of(context).size.height*0.08,
                          decoration: BoxDecoration(
                            color: Color(0xff007360),

                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Center(
                            child: Text("Finish",style: TextStyle(
                                color: Colors.white,fontSize: 14,fontWeight: FontWeight.w600),),
                          ),
                        ),
                      ),
                    ),
                  ],
                )
                ),
              ),
              InkWell(
                onTap: (){
                  Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => MainBoard())
                  );
                },
                child: Text('Skip for now?',style: TextStyle(color: Color(0xff202D50),fontWeight:
                FontWeight.w700,fontSize: 14,fontStyle: FontStyle.normal),),
              ),
              SizedBox(height: 20,)
            ],

          ),
        ),
      ),
    );
  }
}
