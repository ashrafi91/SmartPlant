//
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:firebase_auth/firebase_auth.dart' hide UserCredential;
// import 'package:smartplant/BottomBarScreens/User.dart';
// import 'package:firebase_auth/firebase_auth.dart';
// class Auth {
//   final FirebaseAuth auth = FirebaseAuth.instance;
//
//   Future<UserCredential> handleSignInEmail(String email, String password) async {
//     final user=(await FirebaseAuth.instance.signInWithEmailAndPassword(
//         email: email, password: password)).user;
//     return user;
//   }
//
//   Future<User> handleSignUp(email, password) async {
//     UserCredential result = await auth.createUserWithEmailAndPassword(
//         email: email, password: password);
//     final User user = result.user;
//
//     return user;
//   }
// }