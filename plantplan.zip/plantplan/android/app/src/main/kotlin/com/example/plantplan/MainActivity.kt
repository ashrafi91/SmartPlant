package com.example.plantplan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
